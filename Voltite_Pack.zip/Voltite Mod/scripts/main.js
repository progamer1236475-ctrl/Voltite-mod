// Voltite mod - Volt Conveyor: a high-speed conveyor charged by Voltite
const voltConveyor = new Conveyor("volt-conveyor");
voltConveyor.speed = 0.22;         // base conveyor is ~0.03-0.09; this is very fast
voltConveyor.displayedSpeed = 22;
voltConveyor.health = 120;
voltConveyor.requirements = ItemStack.with(Vars.content.item("voltite"), 1, Items.silicon, 1);
voltConveyor.buildVisibility = BuildVisibility.shown;
voltConveyor.description = "A conveyor laced with Voltite crystal. Moves items far faster than titanium conveyors.";
